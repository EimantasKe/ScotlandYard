package uk.ac.bris.cs.scotlandyard.model;

/**
 * Transports on the map of the Scotland Yard game
 */
public enum Transport {
	TAXI, BUS, UNDERGROUND, FERRY
}
